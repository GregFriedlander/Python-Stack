from flask import Flask, render_template, request, redirect
app = Flask(__name__)

@app.route('/')
def homepage():
    return render_template('index.html')

@app.route('/survey', methods=['Post'])
def info():
    return render_template('submit.html', name = request.form['name'], location = request.form['location'], language = request.form['language'], comment = request.form['textarea'] )



app.run(debug=True)