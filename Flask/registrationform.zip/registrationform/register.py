from flask import Flask, render_template, request, redirect, session, flash
import re
from datetime import datetime
app = Flask(__name__)
app.secret_key = "Thisismysecretkey"
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

@app.route('/')
def homepage():
    return render_template('register.html')

@app.route('/register', methods=['Post'])
def register():
    if not EMAIL_REGEX.match(request.form['email']):
        flash("Invalid Email Address!")
    if len(request.form['first_name']) < 1:
        flash("Please enter a First Name!")
    if len(request.form['last_name']) < 1:
        flash("Please enter a Last Name!")
    if len(request.form['password']) < 1:
        flash("Please enter a Password!")
    if len(request.form['password']) < 8 and len(request.form['password']) > 0:
        flash("Password must be at least 8 characters long")
    if re.search('[0-9]', str(request.form['password'])) is None and re.search('[A-Z]', str(request.form['password'])) is None:
        flash("Your password must contain at least one Uppercase letter and one Number") 
    if request.form['confirmpassword'] != request.form['password']:
        flash("Please confirm password correctly!")
    else:
        flash("Success! Thanks for registering!")
    return redirect('/')





app.run(debug=True)
