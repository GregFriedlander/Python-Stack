from __future__ import unicode_literals

from django.apps import AppConfig


class QuoteWallConfig(AppConfig):
    name = 'quote_wall'
